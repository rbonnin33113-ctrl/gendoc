"""Extractors module for gendoc."""
