"""Utils module for gendoc."""
